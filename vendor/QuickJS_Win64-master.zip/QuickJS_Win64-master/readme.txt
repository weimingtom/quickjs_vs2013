The main documentation is in doc/quickjs.pdf or doc/quickjs.html.
